<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.1/css/mdb.min.css" rel="stylesheet">

	<style type="text/css" rel="stylesheet">
	body{
		background-image:url("images/img5.jpg");
		background-size: cover;
	
	}
	
	a{
		text-decoration:none;
	}
	
	</style>
  </head>
  <body><br><br><br><br><br>
    <center>

	
	
	
    <h1>Please pick the method in which questions should be answered</h1>
		<div class="btn-group" role="group" aria-label="Basic example">
	<a href="theory.php">
  <button type="button" class="btn btn-teal btn-rounded">Theory</button>
  </a>
  
     <a href="obj.php">
  <button type="button" class="btn btn-teal btn-rounded">Multiple Choice</button>
  </a>
   <a href="fill.php">
  <button type="button" class="btn btn-teal btn-rounded">Fill in the Gap</button>
  </a>
</div>


    </center>
	
	
	<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.10.0/js/mdb.min.js"></script>
  </body>
</html>
