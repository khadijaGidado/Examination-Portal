<?php

include "connect.php";

if (isset($_GET['submit'])) {
$fname = $_GET['firstname'];
$lname = $_GET['lastname'];
$level = $_GET['level'];


$query = mysql_query("update ")


?>
